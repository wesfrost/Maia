#!/usr/bin/env bash
set -euo pipefail
echo "First run script. Add format/lint commands here."
